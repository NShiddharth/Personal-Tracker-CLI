import os
import datetime

FILE_NAME = "tracker.txt"
DELIMITER = "|"

# Ensure the tracker file exists
if not os.path.exists(FILE_NAME):
    open(FILE_NAME, "w").close()


def load_data():
    """Load existing data into a list of dicts."""
    data = []
    with open(FILE_NAME, "r") as f:
        for line in f:
            parts = line.strip().split(DELIMITER)
            if len(parts) == 4:
                date, category, description, amount = parts
                data.append({
                    "date": date,
                    "category": category,
                    "description": description,
                    "amount": amount
                })
    return data


def save_data(data):
    """Write all items to the tracker file."""
    with open(FILE_NAME, "w") as f:
        for item in data:
            line = f"{item['date']}{DELIMITER}{item['category']}{DELIMITER}{item['description']}{DELIMITER}{item['amount']}\n"
            f.write(line)


def clear_screen():
    """Clear terminal screen for clean UI."""
    os.system("cls" if os.name == "nt" else "clear")


def print_header():
    print("\n==============================")
    print("   📘 PERSONAL TRACKER CLI")
    print("==============================\n")


def list_items(data):
    """Show all items in table format."""
    if not data:
        print("📂 No entries found yet.\n")
        return

    print(f"{'No.':<4} {'Date':<12} {'Category':<12} {'Description':<25} {'Amount':>8}")
    print("-" * 65)
    for i, item in enumerate(data, start=1):
        print(f"{i:<4} {item['date']:<12} {item['category']:<12} {item['description']:<25} {item['amount']:>8}")
    print()


def add_item(data):
    """Add a new item with category and amount."""
    category = input("📂 Enter category (habit/task/expense): ").strip().capitalize()
    description = input("✏️ Enter description: ").strip()
    amount = "0.00"

    if category.lower() == "expense":
        raw_amount = input("💰 Enter amount (optional): ").strip() or "0.00"
        try:
            float(raw_amount)
            amount = raw_amount
        except ValueError:
            print("⚠️ Invalid amount. Defaulting to 0.00")
            amount = "0.00"

    if not description:
        print("⚠️ Description cannot be empty.\n")
        return

    date = datetime.date.today().strftime("%Y-%m-%d")
    data.append({
        "date": date,
        "category": category,
        "description": description,
        "amount": amount
    })
    save_data(data)
    print("✅ Added successfully!\n")


def update_item(data):
    """Update a selected entry."""
    list_items(data)
    if not data:
        return
    try:
        idx = int(input("Enter item number to update: ").strip())
        if 1 <= idx <= len(data):
            item = data[idx - 1]
            print(f"Editing '{item['description']}' — leave blank to keep old value.\n")

            new_category = input(f"Category ({item['category']}): ").strip() or item['category']
            new_description = input(f"Description ({item['description']}): ").strip() or item['description']
            new_amount = input(f"Amount ({item['amount']}): ").strip() or item['amount']

            data[idx - 1] = {
                "date": item['date'],
                "category": new_category,
                "description": new_description,
                "amount": new_amount
            }
            save_data(data)
            print("🔄 Updated successfully!\n")
        else:
            print("⚠️ Invalid number.\n")
    except ValueError:
        print("⚠️ Please enter a valid number.\n")


def delete_item(data):
    """Delete an item by number."""
    list_items(data)
    if not data:
        return
    try:
        idx = int(input("Enter item number to delete: ").strip())
        if 1 <= idx <= len(data):
            removed = data.pop(idx - 1)
            save_data(data)
            print(f"🗑️ Deleted: {removed['description']}\n")
        else:
            print("⚠️ Invalid number.\n")
    except ValueError:
        print("⚠️ Please enter a valid number.\n")


def view_summary(data):
    """Show summary stats."""
    total_expense = sum(float(item['amount']) for item in data if item['category'].lower() == "expense")
    total_habits = sum(1 for item in data if item['category'].lower() == "habit")
    total_tasks = sum(1 for item in data if item['category'].lower() == "task")

    print("\n📊 Summary:")
    print("-" * 30)
    print(f"Total Habits : {total_habits}")
    print(f"Total Tasks  : {total_tasks}")
    print(f"Total Expense: ₹{total_expense:.2f}")
    print("-" * 30 + "\n")


def menu():
    """Main loop for the CLI app."""
    data = load_data()
    clear_screen()
    print("👋 Welcome to your Personal Tracker!\n")

    while True:
        print_header()
        print("1️⃣  List all items")
        print("2️⃣  Add new item")
        print("3️⃣  Update existing item")
        print("4️⃣  Delete an item")
        print("5️⃣  View summary")
        print("6️⃣  Exit")

        choice = input("Choose an option (1-6): ").strip()

        if choice == "1":
            list_items(data)
        elif choice == "2":
            add_item(data)
        elif choice == "3":
            update_item(data)
        elif choice == "4":
            delete_item(data)
        elif choice == "5":
            view_summary(data)
        elif choice == "6":
            save_data(data)
            print("💾 Data saved successfully. Goodbye!\n")
            print(f"📁 File path: {os.path.abspath(FILE_NAME)}\n")
            break
        else:
            print("⚠️ Invalid choice, please select 1–6.\n")


if __name__ == "__main__":
    menu()
